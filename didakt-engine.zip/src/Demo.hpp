#pragma once

#include "ecs/components/RenderComponent.h"
#include "ecs/components/RigidBodyComponent.h"
#include "ecs/components/SpriteSheetComponent.h"
#include "ecs/components/TilemapComponent.h"
#include "ecs/components/TransformComponent.h"
#include "ecs/RegistryManager.h"
#include "input/InputManager.h"
#include "render/AssetManager.h"
#include "render/Camera.h"
#include "Window.h"
#include <algorithm>
#include <cstdlib>
#include <entt/entity/fwd.hpp>
#include <queue>
#include <SDL_scancode.h>

namespace Demo
{
    static std::queue<entt::entity> entities{};
    static int iTimer = 0;

    void InitAssets(AssetManager& _assetManager, Window& _window, Camera& _camera, RegistryManager& _registryManager)
    {
        _assetManager.LoadTexture("sprite", "assets/images/mario.png");
        _assetManager.LoadTexture("tileset", "assets/images/tileset.png");

        _camera.x = -16;
        _camera.y = -16;
        _camera.zoom = 2;

        //Tilemap
        entt::entity entity = _registryManager.CreateEntity();
        entt::registry& registry = _registryManager.GetRegistry();
        registry.emplace<RenderComponent>(entity, RenderComponent{ "tileset", 0 });
        registry.emplace<TilemapComponent>(entity, TilemapComponent
            {
                {
                    { 222, 270, 198,   0,   5, 270, 174, 174, 150, 120 },
                    { 198, 174, 270,  24,  49,   3,   2,   5, 270, 198 },
                    { 198, 270, 222,  96, 100, 151, 156,  53, 270, 246 },
                    { 222, 270,   0,  50, 100, 223, 252,  49,   5, 174 },
                    { 270,   0,  50, 100, 151, 201, 252, 100,  49,   5 },
                    { 246,  72,  51, 100, 199, 244, 200, 156, 100,  53 },
                    {   4,  50, 100, 151, 201, 250, 176, 276,  28,  77 },
                    { 100, 100,  51, 223, 219, 202, 200, 156,  27,  29 },
                    { 100, 151, 155, 201, 250, 196, 196, 252, 100,  77 },
                    { 153, 201, 250, 202, 226, 226, 220, 204, 100,  77 }
                },
                16, 16, 24
            });
    }

    void GenerateSpriteOnTimer(RegistryManager& _registryManager)
    {
        iTimer++;

        //Test Sprite
        if (iTimer > 1)
        {
            iTimer = 0;

            float speedMin = 25.0f;
            float speedMax = 50.0f;
            float vx = speedMin + static_cast<float>(rand()) / RAND_MAX * (speedMax - speedMin);
            float vy = speedMin + static_cast<float>(rand()) / RAND_MAX * (speedMax - speedMin);

            entt::entity entity = _registryManager.CreateEntity();
            entt::registry& registry = _registryManager.GetRegistry();

            entities.push(entity);

            registry.emplace<RenderComponent>(entity, RenderComponent{ "sprite", 1 });
            registry.emplace<SpriteSheetComponent>(entity, SpriteSheetComponent{ 208, 76, 15, 28 });
            registry.emplace<TransformComponent>(entity, TransformComponent{ { 10.f, 10.f }, { 0.f }, { 1.f, 1.f } });
            registry.emplace<RigidBodyComponent>(entity, RigidBodyComponent{ { vx, vy } });
        }
    }

    void MoveCamera(InputManager& _inputManager, Camera& _camera, double deltaTime)
    {
        const float speed = 200.0f; // pixels/sec

        if (_inputManager.IsKeyDown(Key::W))
            _camera.y -= speed * static_cast<float>(deltaTime);
        if (_inputManager.IsKeyDown(Key::S))
            _camera.y += speed * static_cast<float>(deltaTime);
        if (_inputManager.IsKeyDown(Key::A))
            _camera.x -= speed * static_cast<float>(deltaTime);
        if (_inputManager.IsKeyDown(Key::D))
            _camera.x += speed * static_cast<float>(deltaTime);

        const float zoomSpeed = 1.0f; // zoom units/sec

        if (_inputManager.IsKeyDown(Key::Space))
            _camera.zoom -= zoomSpeed * static_cast<float>(deltaTime);
        if (_inputManager.IsKeyDown(Key::LeftCtrl))
            _camera.zoom += zoomSpeed * static_cast<float>(deltaTime);

        _camera.zoom = std::clamp(_camera.zoom, 0.1f, 5.0f);
    }

    void DestroyOldestEntities(RegistryManager& _registryManager)
    {
        while (entities.size() > 100)
        {
            auto remove = entities.front();
            entities.pop();
            _registryManager.DestroyEntity(remove);
        }
    }
}